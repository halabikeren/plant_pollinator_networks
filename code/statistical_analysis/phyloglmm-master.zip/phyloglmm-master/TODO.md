## plots

* tweak plots, go over all

## 

* rerun all from scratch?
* run pez/phyr longer?
* adjust convergence rules to account for effective sample size


