library(tmbstan)

ff <- tmbstan(hackedmod$obj,chains=1)
