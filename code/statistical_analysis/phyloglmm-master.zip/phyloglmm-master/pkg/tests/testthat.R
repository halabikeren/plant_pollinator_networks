library(testthat)
library(phyloglmm)

test_check("phyloglmm")
