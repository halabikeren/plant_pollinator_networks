- pkgdown site
- work on passing checks
   - ask glmmTMB/lme4 maintainers to export more functions?
   - copy functions?
   - formula utils in separate package?
- more tests
- github actions test (use_github_actions() + correction for subdir? check glmmTMB)
- badges?
- extend hack_function:
   - use with more functions
   - allow multiple insertions/changes
- Rcpp version/core of phylo.to.Z?
- document redundant phylo/phyloZ args: phyloZ to save time in recomputing it
- better naming/diagnostics (label internal nodes?)
- resolve warning in glmmTMB fitting: "number of items to replace is not a multiple of replacement length", glmmTMB_phylo_setup.R:138:2
- utils for predictions at tips?


