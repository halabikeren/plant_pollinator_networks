#' data
#'
#' #' Simple data from Garamszegi chapter 11
"garamszegi_phy"

#' @rdname garamszegi_phy
"garamszegi_pois_missing"

#' @rdname garamszegi_phy
"garamszegi_repeat"

#' @rdname garamszegi_phy
"garamszegi_simple"

#' @rdname garamszegi_phy
"garamszegi_pois"

#' @rdname garamszegi_phy
"garamszegi_effect"
