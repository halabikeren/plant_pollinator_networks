Tweetable Abstract

New formulation of phylogenetic GLMM implemented in lme4 and glmmTMB is computationally efficient, and more flexible.

